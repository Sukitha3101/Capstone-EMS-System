package com.expense.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.expense.dto.ExpenseDto;
import com.expense.dto.NotificationDto;
import com.expense.entity.Expense;
import com.expense.entity.Notification;
import com.expense.exception.ResourceNotFoundException;
import com.expense.service.NotificationService;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/notifications")
public class NotificationController {

	@Autowired
	private NotificationService notificationService;
	
	@PostMapping
    public Notification createNotification(@RequestBody NotificationDto notificationDTO) {
        return notificationService.saveNotification(notificationDTO);
    }

    @GetMapping
    public List<Notification> getAllNotifications() {
        return notificationService.getAllNotifications();
    }
    
    @PutMapping("/{id}")
    public Notification updateNotification(@PathVariable Long id, @RequestBody NotificationDto notificationDTO) throws ResourceNotFoundException{
    	return notificationService.updateNotification(id, notificationDTO);
    }


    @DeleteMapping("/{id}")
    public void deleteNotification(@PathVariable Long id) {
    	notificationService.deleteNotification(id);
    }
    
    @DeleteMapping
    public void deleteAllNotification() {
    	notificationService.deleteAllNotification();
    }
    
}
