package com.example;

@SpringBootTest
class Demo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}